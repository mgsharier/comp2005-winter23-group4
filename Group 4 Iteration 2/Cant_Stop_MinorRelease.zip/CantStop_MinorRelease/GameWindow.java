// GAME UI CLASS


// Imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import javax.imageio.*;
//import javax.management.monitor.GaugeMonitor;


//
public class GameWindow extends JFrame implements ActionListener, MouseListener
{

    // Global variables
    private final String BG_IMAGE_PATH = "ingamebg.jpg";
    private Image bgImage;
    
    // gui components 
    private ImgPanel bgPanel;
    private JPanel topPanel,bottomPanel0, bottomPanel1,bottomPanel2,  rightPanel;               // Panels
    private JLabel instructionLabel, dice_label1, dice_label2, dice_label3, dice_label4;        // UI labels
    private Combination dice_comb1, dice_comb2, dice_comb3, dice_comb4, dice_comb5, dice_comb6; // Combination buttons
    private JLabel infoLabel;       
    private JRadioButton rb1, rb2;   
    private JButton topButton, roll_Button;                
    private GridSquare [][] gridSquares;    // squares to appear in grid formation in the bottom panel
    private int rows,columns,counter;                // the size of the grid
    private JPanel glassPane;
    // 

    private Game current_game;
    private boolean playerRisk;
    private int selectionCounter;
    private int runnerCounter;
    private ArrayList<Integer> runnerCoordinates;
    private int rolledDice;
    private HashMap<Integer,Integer> runnerPosition;
    

    /*
     *  constructor method takes as input how many rows and columns of gridsquares to create
     */
    public GameWindow(int rows, int columns)
    {
        this.rows = rows;
        this.columns = columns;
        this.setSize(1000,800);
        this.counter = 0;
        this.playerRisk = false;
        this.selectionCounter= 0;
        this.runnerCounter=0;
        runnerCoordinates = new ArrayList<>();
        this.rolledDice=0;
        runnerPosition= new HashMap<>();
        

        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");
        ArrayList<Player> player_array = new ArrayList<>();
        player_array.add(player1); player_array.add(player2);   // Temporary code to generate players 
                                                                // would normally be created from game setup creation

        current_game = new Game(player_array);


        // background image setup
        loadAssets();
        bgPanel = new ImgPanel(bgImage);
        
        
        // first create and set the panels
        topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        topPanel.setBorder(BorderFactory.createLineBorder(Color.black));    //

        bottomPanel0 = new JPanel();
        bottomPanel0.setLayout(new BorderLayout());
        bottomPanel0.setBorder(BorderFactory.createLineBorder(Color.black));

        bottomPanel1 = new JPanel();
        bottomPanel1.setBorder(BorderFactory.createLineBorder(Color.black));
        bottomPanel1.setPreferredSize(new Dimension(300,50));
        
        bottomPanel2 = new JPanel();
        bottomPanel2.setLayout(new GridLayout(rows, columns));
        bottomPanel2.setSize(200,200);
        bottomPanel2.setBorder(BorderFactory.createLineBorder(Color.black));
        
        rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.PAGE_AXIS));
        rightPanel.setPreferredSize(new Dimension(300,200));
        rightPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        

        // components
        // for the top panel:
        instructionLabel = new JLabel("Click the Squares!");
        infoLabel = new JLabel("No square clicked yet.");
    
        topButton = new JButton("Options");
        topButton.addActionListener(this);

        topPanel.add (topButton);
        

        // for the bottom panel:    
        // create the squares and add them to the grid
        gridSquares = new GridSquare[rows][columns];
        for ( int x = 0; x < rows; x ++)
        {
            for ( int y = 0; y < columns; y ++)
            {
                gridSquares[x][y] = new GridSquare(x, y);
                gridSquares[x][y].setColor(1);
                bottomPanel2.add(gridSquares[x][y]);
                gridSquares[x][y].setBorder(BorderFactory.createLineBorder(Color.black));
            }}
        

        // create board
        for ( int x = 0; x < 14; x ++){    
            if(x<5){
                for( int z = 6-x ; z<= 6+ x ; z++){
                gridSquares[x+1][z+1].setColor(2);    
                gridSquares[x+1][z+1].setSize(300, 300);
                gridSquares[x+1][z+1].addMouseListener(this);
                gridSquares[x+1][z+1].setBorder(BorderFactory.createLineBorder(Color.black));}
                
            }
            if(x>=5 && x<=7){
                for( int z = 6-5 ; z<= 6+ 5 ; z++){
                gridSquares[x+1][z+1].setColor(2);
                gridSquares[x+1][z+1].setSize(300, 300);
                gridSquares[x+1][z+1].addMouseListener(this);
                gridSquares[x+1][z+1].setBorder(BorderFactory.createLineBorder(Color.black));}
            } 
            if(x>=8 && x<=12){
                for( int z = x-6 ; z<=18-x  ; z++){
                gridSquares[x+1][z+1].setColor(2);
                gridSquares[x+1][z+1].setSize(300, 300);
                gridSquares[x+1][z+1].addMouseListener(this);
                gridSquares[x+1][z+1].setBorder(BorderFactory.createLineBorder(Color.black));}
            }

        }

        // column Numbers
        int r = 5;
        for(int c = 2; c <= 12; c++){
            gridSquares[Math.abs(r)][c].set_Header(c);
            r--;
        }

        // add panels to bottomPanel0
        bottomPanel0.add(bottomPanel1, BorderLayout.NORTH);
        bottomPanel0.add(bottomPanel2, BorderLayout.CENTER);

        
        // Right panel contents
        roll_Button = new JButton("ROLL");
        roll_Button.setAlignmentX(CENTER_ALIGNMENT);
        roll_Button.setPreferredSize(new Dimension(50,50));
        roll_Button.addActionListener(this);

        dice_label1 = new JLabel("N");
        dice_label1.setAlignmentX(CENTER_ALIGNMENT);
        dice_label1.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_label2 = new JLabel("N");
        dice_label2.setAlignmentX(CENTER_ALIGNMENT);
        dice_label2.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_label3 = new JLabel("N");
        dice_label3.setAlignmentX(CENTER_ALIGNMENT);
        dice_label3.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_label4 = new JLabel("N");
        dice_label4.setAlignmentX(CENTER_ALIGNMENT);
        dice_label4.setFont(new Font("Ariel", Font.PLAIN, 30));

        dice_comb1 = new Combination(0);
        dice_comb1.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb1.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb1.setColor(2);
        dice_comb1.setVisible(false);
        dice_comb1.addMouseListener(this); 

        dice_comb2 = new Combination(0);
        dice_comb2.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb2.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb2.setVisible(false);
        dice_comb2.addMouseListener(this); 

        dice_comb3 = new Combination(0);
        dice_comb3.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb3.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb3.setVisible(false);
        dice_comb3.addMouseListener(this); 

        dice_comb4 = new Combination(0);
        dice_comb4.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb4.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb4.setVisible(false);
        dice_comb4.addMouseListener(this); 
        
        dice_comb5 = new Combination(0);
        dice_comb5.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb5.setFont(new Font("Ariel", Font.PLAIN, 30)); 
        dice_comb5.setVisible(false);
        dice_comb5.addMouseListener(this); 
        
        dice_comb6 = new Combination(0);
        dice_comb6.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb6.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb6.setVisible(false);
        dice_comb6.addMouseListener(this); 
        
        rightPanel.add(Box.createRigidArea(new Dimension(0,50)));
        rightPanel.add(Box.createVerticalGlue());
        rightPanel.add(dice_label1);
        rightPanel.add(dice_label2);
        rightPanel.add(dice_label3);
        rightPanel.add(dice_label4);
        rightPanel.add(dice_comb1);
        rightPanel.add(dice_comb2);
        rightPanel.add(dice_comb3);
        rightPanel.add(dice_comb4);
        rightPanel.add(dice_comb5);
        rightPanel.add(dice_comb6);
        rightPanel.add(Box.createRigidArea(new Dimension(0,150)));
        rightPanel.add(roll_Button);
        rightPanel.add(Box.createRigidArea(new Dimension(0,150)));
        

        //topPanel.setOpaque(false);
        bottomPanel0.setOpaque(false);
        bottomPanel1.setOpaque(false);
        bottomPanel2.setOpaque(false);
        //rightPanel.setOpaque(false);


        // now add the top and bottom panels to the main frame
        bgPanel.setLayout(new BorderLayout());
        bgPanel.add(topPanel, BorderLayout.NORTH);
        bgPanel.add(bottomPanel0, BorderLayout.CENTER);       
        bgPanel.add(rightPanel, BorderLayout.EAST);
        setContentPane(bgPanel);


        //access glass pane for OptionsMenu
        glassPane =(JPanel) this.getGlassPane();
        //glassPane.setBackground( new Color(255, 0, 0, 20) );
        glassPane.addMouseListener(new MouseAdapter(){});
        glassPane.setLayout(new GridBagLayout());

        JPanel glassJPanel = new JPanel();
        glassJPanel.setLayout(new BoxLayout(glassJPanel, BoxLayout.PAGE_AXIS));
        glassJPanel.setPreferredSize(new Dimension(300,420));
        glassJPanel.setBackground(Color.red);
        glassJPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        glassJPanel.setAlignmentX(CENTER_ALIGNMENT);
        glassJPanel.setAlignmentY(CENTER_ALIGNMENT);
        
        // buttons to save or exit game
        JButton returnToGameButton = new JButton("Return to game");
        returnToGameButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
            glassPane.setVisible(false);
            }
        }); //
        
        JButton exitGameButton = new JButton("Return to Main Menu");
        exitGameButton.addActionListener(new ActionListener()
        {
        public void actionPerformed(ActionEvent e) {
        dispose();
        MainMenu menu = new MainMenu();            }
        }); //

        JButton saveGameButton = new JButton("Save game");
        saveGameButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) {
                //call method to save
                current_game.saveGame();
            }
        }); //

        JButton buttons[] = {returnToGameButton,saveGameButton,exitGameButton};
        arrangeButtons(buttons);

        rb1 = new JRadioButton("Size 1");
        rb1.setAlignmentX(CENTER_ALIGNMENT);
      
        rb2 = new JRadioButton("Size 2");
        rb2.setAlignmentX(CENTER_ALIGNMENT);
        ButtonGroup b_Group = new ButtonGroup();
        b_Group.add(rb1);b_Group.add(rb2);
        rb1.addActionListener(new ActionListener()
        {
        public void actionPerformed(ActionEvent e) {

            System.out.println("rb1");
            getContentPane().setPreferredSize(new Dimension(1000,1000));
            
        }
        }); //
        rb2.addActionListener(new ActionListener()
        {
        public void actionPerformed(ActionEvent e) {

            System.out.println("rb2");
            getContentPane().setPreferredSize(new Dimension(2000,2000));
            // setVisible(true);
            
        }
        }); //



        // add components to glassPanel
        glassJPanel.add(Box.createVerticalGlue());
        glassJPanel.add(Box.createRigidArea(new Dimension(0,25)));
        glassJPanel.add(returnToGameButton);
        glassJPanel.add(Box.createRigidArea(new Dimension(0,50)));
        glassJPanel.add(exitGameButton);
        glassJPanel.add(Box.createRigidArea(new Dimension(0,50)));
        glassJPanel.add(saveGameButton);  
        glassJPanel.add(Box.createRigidArea(new Dimension(0,30)));  
        glassJPanel.add(rb1);
        glassJPanel.add(rb2);    
        
        glassPane.add(glassJPanel);

        // housekeeping : behaviour
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setVisible(true);
    }
    

    //
    private void loadAssets() {
        try {
            bgImage = ImageIO.read(new File(BG_IMAGE_PATH));
        }
        catch(Exception e) {
            System.out.println("failed to load in-game background image; " + e.getMessage());
        }
    }
    

    //
    public void stopTurn(){
    
                 for(int s =0;s<runnerCoordinates.size();s++){
                    int r = runnerPosition.get(runnerCoordinates.get(s));
                    gridSquares[r][runnerCoordinates.get(s)].saveRunner();}         
    }


    //
    public void simulateDiceRoll(){

            selectionCounter=0;
            boolean failCombination = false;
            Dice dice = new Dice();

            // a temporary condition to test fail turn (work in progress)
            if(rolledDice>=4){
                while(failCombination==false)
                {
                    if(runnerCoordinates.contains(dice.get_comb1())==false
                    && runnerCoordinates.contains(dice.get_comb2())==false
                    && runnerCoordinates.contains(dice.get_comb3())==false
                    && runnerCoordinates.contains(dice.get_comb4())==false
                    && runnerCoordinates.contains(dice.get_comb5())==false
                    && runnerCoordinates.contains(dice.get_comb6())==false)
                    {
                        failCombination = true;
                    }
                    else
                    {
                        dice = new Dice();
                    }
                }
            }
            
            //get face values from Dice
            int w = dice.get_val1();
            int x = dice.get_val2();
            int y = dice.get_val3();
            int z = dice.get_val4();
            
            //Display values
            dice_label1.setText(""+w);          
            dice_label2.setText(""+x);            
            dice_label3.setText(""+y);
            dice_label4.setText(""+z);

            dice_comb1.setText(""+w+" "+x);
            dice_comb1.setValue(dice.get_comb1());
            dice_comb1.setVisible(true);
            
            dice_comb2.setText(""+x+" "+y);
            dice_comb2.setValue(dice.get_comb2());
            dice_comb2.setVisible(true);

            dice_comb3.setText(""+y+" "+z);
            dice_comb3.setValue(dice.get_comb3());
            dice_comb3.setVisible(true);

            dice_comb4.setText(""+w+" "+y);
            dice_comb4.setValue(dice.get_comb4());
            dice_comb4.setVisible(true);
  
            dice_comb5.setText(""+x+" "+z);
            dice_comb5.setValue(dice.get_comb5());
            dice_comb5.setVisible(true);
 
            dice_comb6.setText(""+w+" "+z);
            dice_comb6.setValue(dice.get_comb6());
            dice_comb6.setVisible(true);
            
            // Fail detection
            if(runnerCounter==3 && runnerCoordinates.contains(dice.get_comb1())==false
            && runnerCoordinates.contains(dice.get_comb2())==false
            && runnerCoordinates.contains(dice.get_comb3())==false
            && runnerCoordinates.contains(dice.get_comb4())==false
            && runnerCoordinates.contains(dice.get_comb5())==false
            && runnerCoordinates.contains(dice.get_comb6())==false){
                
                rightPanel.setBackground(Color.RED);
                dice_comb1.setText("failed");
                this.stopTurn();
        
            }
            
 
    }



    //
    public void arrangeButtons(JButton[] buttons)
    {
        for (JButton button : buttons)
        button.setAlignmentX(CENTER_ALIGNMENT);
    }



    /*
     *  handles actions performed in the gui
     *  this method must be present to correctly implement the ActionListener interface
     */
    public void actionPerformed(ActionEvent aevt)
    {
        // get the object that was selected in the gui
        Object selected = aevt.getSource();
                
        // if resetting the squares' colours is requested then do so
        if ( selected.equals(topButton) )
        {
            glassPane.setVisible(true);
        }
        else if (selected.equals(roll_Button)){
                rolledDice+=1;
                simulateDiceRoll();
        }
        
    }


    // Mouse Listener events
    public void mouseClicked(MouseEvent mevt)
    {
        Object selected = mevt.getSource();
        
        if (selected instanceof Combination && selectionCounter<2)
        {
            selectionCounter++;
            Combination currCombination = (Combination ) selected;
            int column = currCombination.getValue();
            boolean runnerFound = false; 
            currCombination.setText("You selected" + column);
            if(1<column && column<8){
                for ( int r = 8-column; r <= column+6; r++)
                {
                    if(gridSquares [r][column].containsRunner()){
                       gridSquares [r][column].removeRunner();
                       gridSquares [r-1][column].setRunner();
                       runnerPosition.put(column, r-1);
                       runnerFound=true;
                    }
                }
                if(runnerFound==false && runnerCounter<3){
                   gridSquares [column+6][column].setRunner();
                   runnerCoordinates.add(column);
                   runnerPosition.put(column, column+6);
                   runnerCounter++;
                   
                }
            }
            else if(7<column && column<13){
                for ( int r = column-6; r <= (20-column); r++)
                {
                    if(gridSquares [r][column].containsRunner()){
                       gridSquares [r-1][column].setRunner();
                       runnerPosition.put(column,r-1);
                       gridSquares [r][column].removeRunner();
                       runnerFound=true;
                    }
                }
                if(runnerFound==false && runnerCounter<3){
                   gridSquares [20-column][column].setRunner();
                   runnerCoordinates.add(column);
                   runnerPosition.put(column, 20-column);
                   runnerCounter++;
                }
            }}
        else if (selected instanceof Combination && selectionCounter==2){
            Combination invalid = (Combination ) selected;
            invalid.setText("INVALID");
        }
        System.out.println(runnerPosition);
        System.out.println(runnerCoordinates);
    }
    



    // not used but must be present to fulfil MouseListener contract
    public void mouseEntered(MouseEvent arg0){}
    public void mouseExited(MouseEvent arg0) {}
    public void mousePressed(MouseEvent arg0) {}
    public void mouseReleased(MouseEvent arg0) {}
}
