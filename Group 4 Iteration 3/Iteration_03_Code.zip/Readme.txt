Cant Stop Iteration 3 minor release

Folder: Iteration3_MinorRelease

compile: javac *.java

run: java Driver