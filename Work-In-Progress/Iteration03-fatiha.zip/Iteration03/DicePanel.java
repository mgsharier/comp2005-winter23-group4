 

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;

public class DicePanel extends JPanel {

    private static final long DEFAULT_ROLL_DURATION = 3000;
    private final int FRAME_DURATION = 100;

    private final int DIE_MAX_VALUE = 6;


    private final Random random;
    private Timer timer;
    private int val1, val2, val3, val4;

    private long timeElapsed;
    private Consumer<List<Integer>> callback;

    private JButton rollButton;

    public DicePanel(int rollDuration) {
        random = new Random();
        val1 = 1;
        val2 = 1;
        val3 = 1;
        val4 = 1;
        setPreferredSize(new Dimension(300, 300));
        setLayout(new BorderLayout());
        rollButton = new JButton("Roll!");
        rollButton.setPreferredSize(new Dimension(100, 50));
        rollButton.addActionListener(e -> roll());
        add(rollButton, BorderLayout.SOUTH);
//        setBackground(Color.WHITE);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        int dieSize = calculateDieSize();
        int y = getHeight() / 2;
        int x1 = dieSize / 5 + dieSize / 2;
        int x2 = x1 + dieSize + dieSize / 5;
        int x3 = x2 + dieSize + dieSize / 5;
        int x4 = x3 + dieSize + dieSize / 5;

        DrawDiceUtil.drawDie(x1, y, val1, dieSize, g);
        DrawDiceUtil.drawDie(x2, y, val2, dieSize, g);
        DrawDiceUtil.drawDie(x3, y, val3, dieSize, g);
        DrawDiceUtil.drawDie(x4, y, val4, dieSize, g);
    }

    public void setCallback(Consumer<List<Integer>> callback) {
        this.callback = callback;
    }

    private void randomizeDice() {
        val1 = random.nextInt(DIE_MAX_VALUE) + 1;
        val2 = random.nextInt(DIE_MAX_VALUE) + 1;
        val3 = random.nextInt(DIE_MAX_VALUE) + 1;
        val4 = random.nextInt(DIE_MAX_VALUE) + 1;
    }

    private int calculateDieSize() {
        return getWidth() / 5;
    }

    public List<Integer> rollInstantly() {
        randomizeDice();
        repaint();
        return List.of(val1, val2, val3, val4);
    }

    public void roll(long rollDuration) {
        if (timer != null && timer.isRunning()) {
            System.out.println("ALREADY RUNNING");
            return;
        }
        timer = new Timer(FRAME_DURATION, e -> {
            timeElapsed += FRAME_DURATION;
            if (timeElapsed >= rollDuration) {
                if (callback != null)
                    callback.accept(List.of(val1, val2, val3, val4));
                rollButton.setEnabled(true);
                repaint();
                timer.stop();
                return;
            }
            randomizeDice();
            repaint();
        });
        rollButton.setEnabled(false);
        timeElapsed = 0;
        timer.start();
    }

    public List<Integer> getRollValues() {
        return List.of(val1, val2, val3, val4);
    }

    public void roll() {
        roll(DEFAULT_ROLL_DURATION);
    }
}
