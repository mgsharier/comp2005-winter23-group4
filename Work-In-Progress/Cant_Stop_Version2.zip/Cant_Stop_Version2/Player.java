import java.awt.*;
import java.util.ArrayList;


public class Player { 

    private String name;
    private ArrayList<Integer> player_marker;

    public Player(String p_name)
    {
        super();
        this.name = p_name;
        player_marker = new ArrayList<>();
    }

    
}
