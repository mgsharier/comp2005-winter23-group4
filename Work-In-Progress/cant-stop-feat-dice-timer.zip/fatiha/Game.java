package fatiha;

import java.util.*;
import java.io.*;

public class Game {

    
    private  ArrayList<Player> player_list; 
    private Player curr_turn_player;
    private int number_of_players;
    private ArrayList<Integer> game_runnerCoordinates;



    public Game(ArrayList<Player> playerList )
    {
        super();
        this.player_list = playerList;
        this.number_of_players = playerList.size();
        // for now, starting turn selects first player from player list
        this.curr_turn_player = playerList.get(0);
    }

    public ArrayList<Player> get_Players(){
        return this.player_list;
    }

    public Player get_currentTurnPlayer(){
        return this.curr_turn_player;
    }

    public int get_numOfPlayers(){
        return this.number_of_players;
    }

    public void saveGame(){

        String fileName = "data.ser";
        try {
                    FileOutputStream fileOut = new FileOutputStream(fileName);
                    ObjectOutputStream out = new ObjectOutputStream(fileOut);
                    // out.writeObject(this.get_Players());
                    // out.writeObject(this.get_currentTurnPlayer());
                    // out.writeObject(this.get_numOfPlayers());

                    out.writeObject(this.game_runnerCoordinates);
                    
                    out.close();
                    fileOut.close();
                    System.out.println("Data saved to " + fileName);
                    
                    
                
                } catch (IOException et) {
                    et.printStackTrace();
                }

    }
    
}
