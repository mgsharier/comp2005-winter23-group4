package fatiha;

import java.awt.*;
import javax.swing.*;
public class Combination extends JButton
{
    private int value;     

    /**
     * Constructor for objects of class Combination
     */
    public Combination(int value)
    {
       super();
       this.value = value;
       this.setSize(40,40);
    }
    
    public int getValue(){
        return this.value;
    }
    
      
    
    public void setValue(int val){
        this.value= val;
    }

    
    
    public void setColor( int decider)
    {
        if(decider==1){
            this.setBackground(Color.orange);    
        }
        else if( decider == 2){
            this.setBackground(Color.BLUE);
        }
        else if( decider == 3){
            this.setBackground(Color.PINK);
        }
        else if( decider == 4){
            this.setBackground(Color.GREEN);
        }
        else if( decider == 5){
            this.setBackground(Color.RED);
        }
        else if( decider == 6){
            this.setBackground(Color.yellow);
        }
    }
}
