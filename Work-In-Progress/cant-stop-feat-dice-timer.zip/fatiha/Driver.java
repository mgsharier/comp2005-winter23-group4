package fatiha;

/*
 *  Another simple GUI demonstration using swing.
 *  Here the GridSquare class extends JPanel and
 *  holds its coordinates in the grid as attributes.
 *  @author mhatcher
 */
public class Driver
{
    public static void main(String[] args)
    {
        // create a new GUI window
        //WindowDemo demo = new WindowDemo(17, 17);
        MainMenu menu = new MainMenu();
    }
}
