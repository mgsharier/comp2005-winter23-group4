package fatiha;

import java.util.Random;

public class Dice {

    private int val1,val2,val3,val4, comb1,comb2,comb3,comb4,comb5,comb6;
    
    public Dice()
    {
        super();
        Random rand = new Random();
        val1 = rand.nextInt(6) + 1;
        val2 = rand.nextInt(6) + 1;
        val3 = rand.nextInt(6) + 1;
        val4 = rand.nextInt(6) + 1;

        comb1 = val1 + val2;    
        comb2 = val2 + val3;
        comb3 = val3 + val4;
        comb4 = val1 + val3;
        comb5 = val2 + val4;
        comb6 = val1 + val4;

    }

    public int get_val1()
    {
        return this.val1;
    }

    public int get_val2()
    {
        return this.val2;
    }

    public int get_val3()
    {
        return this.val3;
    }

    public int get_val4()
    {
        return this.val4;
    }

    public int get_comb1()
    {
        return this.comb1;
    }

    public int get_comb2()
    {
        return this.comb2;
    }

    public int get_comb3()
    {
        return this.comb3;
    }

    public int get_comb4()
    {
        return this.comb4;
    }

    public int get_comb5()
    {
        return this.comb5;
    }

    public int get_comb6()
    {
        return this.comb6;
    }

}
