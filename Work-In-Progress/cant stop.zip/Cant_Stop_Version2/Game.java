import java.util.ArrayList;


public class Game {

    private  ArrayList<Player> player_list; 
    private Player curr_turn_player;
    private int number_of_players;

    public Game(ArrayList<Player> playerList )
    {
        super();
        this.player_list = playerList;
        this.number_of_players = playerList.size();
        // for now, starting turn selects first player from player list
        this.curr_turn_player = playerList.get(0);

    }

    
}
