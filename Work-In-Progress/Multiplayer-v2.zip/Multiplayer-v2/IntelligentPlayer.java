import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import javax.imageio.*;

public class IntelligentPlayer extends Player
{
    private int rows,columns,counter;
    private boolean playerRisk;
    private int selectionCounter;
    private int runnerCounter;
    private int rolledDice;
    private String name;
    private boolean failCombination;
    private ArrayList<Integer> runnerCoordinates;
    
    public IntelligentPlayer(String name)
    {
        super(name);
        System.out.println(selectionCounter);
    }
     
    

}

