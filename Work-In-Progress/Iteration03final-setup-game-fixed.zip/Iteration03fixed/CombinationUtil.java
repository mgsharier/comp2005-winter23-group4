import java.util.ArrayList;
import java.util.List;

public class CombinationUtil {
    
    public static List<List<Integer>> createPairCombinations(List<Integer> list) {
        List<List<Integer>> combinations = new ArrayList<>();
        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = i + 1; j < list.size(); j++) {
                combinations.add(List.of(list.get(i), list.get(j)));
            }
        }
        return combinations;
    }
}
