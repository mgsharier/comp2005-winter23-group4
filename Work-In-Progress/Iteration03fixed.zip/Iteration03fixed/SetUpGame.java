import javax.security.auth.kerberos.KerberosKey;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class SetUpGame extends JFrame implements ActionListener{

    private JButton go_back_button, player1Button, player2Button, player3Button, player4Button,  createGame_button, addPlayerButton;
    private JButton createGame_button2, removePlayer_button;
    private JPanel mainPanel, topPanel, centerPanel, centerPanel1, centerPanel2, centerPanel3 ,  bottomPanel, bottomPanel1,  bottomPanel2;
    private JTextField player_name1, player_name2, player_name3, player_name4;
    private JLabel player1Label, player2Label, player3Label, player4Label;
    private int player_counter = 1;

    private IntelligentPlayer player2_AI = new IntelligentPlayer("Alexa");
    private IntelligentPlayer player3_AI = new IntelligentPlayer("Intell PLayer 3"); 
    private IntelligentPlayer player4_AI = new IntelligentPlayer("Intell Player 4");
    private HumanPlayer player1_Hum = new HumanPlayer("Player 1") ;
    private HumanPlayer player2_Hum, player3_Hum, player4_Hum;
    private Player[] player_array = {player1_Hum ,player2_AI, player3_AI, player4_AI};
    private Timer timer;
    
    //
    public SetUpGame()
    {
        // top panel
        topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.LINE_AXIS));

        go_back_button = new JButton("Back");
        go_back_button.setFont(new Font("Arial", Font.PLAIN, 15));
        go_back_button.setPreferredSize(new Dimension(70,30));
        go_back_button.addActionListener(this);

        topPanel.add(go_back_button);
        topPanel.add(Box.createHorizontalGlue());        


        // bottom panel - contains create game button

        bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(2,1));

        //
        bottomPanel1 = new JPanel();
        bottomPanel1.setLayout(new BoxLayout(bottomPanel1, BoxLayout.LINE_AXIS));

        createGame_button = new JButton("Create game");
        createGame_button.setFont(new Font("Arial", Font.PLAIN, 15));
        createGame_button.setPreferredSize(new Dimension(150,30));
        createGame_button.addActionListener(this);

        bottomPanel1.add(Box.createHorizontalGlue());
        //bottomPanel1.add(createGame_button);

        //
        bottomPanel2 = new JPanel();
        bottomPanel2.setLayout(new FlowLayout());

        createGame_button2 = new JButton("Create Game");
        createGame_button2.setFont(new Font("Arial", Font.PLAIN, 15));
        createGame_button2.setPreferredSize(new Dimension(150,30));
        createGame_button2.addActionListener(this);
        createGame_button2.setVisible(true);

        removePlayer_button = new JButton("Remove Player");
        removePlayer_button.setFont(new Font("Arial", Font.PLAIN, 15));
        removePlayer_button.setPreferredSize(new Dimension(150,30));
        removePlayer_button.addActionListener(this);
        removePlayer_button.setVisible(false);

        bottomPanel2.add(createGame_button2);
        bottomPanel2.add(removePlayer_button);

        //
        bottomPanel.add(bottomPanel2);
        bottomPanel.add(bottomPanel1);




        // center panel - contains addPlayer button
        centerPanel3 = new JPanel();
        centerPanel3.setLayout(new BoxLayout(centerPanel3, BoxLayout.PAGE_AXIS));

        player1Label = new JLabel("Player 1");
        player1Label.setPreferredSize(new Dimension(new Dimension(200,40)));
        player1Label.setMaximumSize(new Dimension(100,50));
        player1Label.setFont(new Font("Arial", Font.PLAIN, 15));
        player1Label.setAlignmentX(RIGHT_ALIGNMENT);

        player2Label = new JLabel("Player 2");
        player2Label.setPreferredSize(new Dimension(new Dimension(200,40)));
        player2Label.setMaximumSize(new Dimension(100,50));
        player2Label.setFont(new Font("Arial", Font.PLAIN, 15));
        player2Label.setAlignmentX(RIGHT_ALIGNMENT);
        player2Label.setVisible(false);

        player3Label = new JLabel("Player 3");
        player3Label.setPreferredSize(new Dimension(new Dimension(200,40)));
        player3Label.setMaximumSize(new Dimension(100,50));
        player3Label.setFont(new Font("Arial", Font.PLAIN, 15));
        player3Label.setAlignmentX(RIGHT_ALIGNMENT);
        player3Label.setVisible(false);

        player4Label = new JLabel("Player 4");
        player4Label.setPreferredSize(new Dimension(new Dimension(200,40)));
        player4Label.setMaximumSize(new Dimension(100,50));
        player4Label.setFont(new Font("Arial", Font.PLAIN, 15));
        player4Label.setAlignmentX(RIGHT_ALIGNMENT);
        player4Label.setVisible(false);

        centerPanel3.setPreferredSize(new Dimension(70,200));
        centerPanel3.add(player1Label);
        centerPanel3.add(player2Label);
        centerPanel3.add(player3Label);
        centerPanel3.add(player4Label);

        


        //        
        centerPanel1 = new JPanel();
        //centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        //centerPanel.setLayout(new BorderLayout());
        centerPanel1.setLayout(new BoxLayout(centerPanel1, BoxLayout.PAGE_AXIS));
        

        player_name1 = new JTextField("Default name ");
        player_name1.setMaximumSize(new Dimension(110,50));
        player_name1.setPreferredSize(new Dimension(new Dimension(200,50)));
        player_name1.setFont(new Font("Arial", Font.PLAIN, 15));
        player_name1.setAlignmentX(RIGHT_ALIGNMENT);
        
       

        player_name2 = new JTextField("Default name 2");
        player_name2.setMaximumSize(new Dimension(110,50));
        player_name2.setPreferredSize(new Dimension(new Dimension(200,50)));
        player_name2.setFont(new Font("Arial", Font.PLAIN, 15));
        player_name2.setVisible(false);
        player_name2.setAlignmentX(RIGHT_ALIGNMENT);
       

        player_name3 = new JTextField("Defualt name 3");
        player_name3.setMaximumSize(new Dimension(110,50));
        player_name3.setPreferredSize(new Dimension(new Dimension(200,50)));
        player_name3.setFont(new Font("Arial", Font.PLAIN, 15));
        player_name3.setVisible(false);
        player_name3.setAlignmentX(RIGHT_ALIGNMENT);
        

        player_name4 = new JTextField("Default name 4");
        player_name4.setMaximumSize(new Dimension(110,50));
        player_name4.setPreferredSize(new Dimension(new Dimension(200,50)));
        player_name4.setFont(new Font("Arial", Font.PLAIN, 15));
        player_name4.setVisible(false);
        player_name4.setAlignmentX(RIGHT_ALIGNMENT);
        
        centerPanel1.setPreferredSize(new Dimension(110,200));
        
        centerPanel1.add(player_name1); 
        centerPanel1.add(player_name2);
        centerPanel1.add(player_name3);
        centerPanel1.add(player_name4);   
            
        
        
        
        //
        centerPanel2 = new JPanel();
        centerPanel2.setLayout(new BoxLayout(centerPanel2, BoxLayout.PAGE_AXIS));

        player1Button = new JButton("Enter Player 1");
        player1Button.setMaximumSize(new Dimension(140,50));
        player1Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player1Button.addActionListener(this);
 

        player2Button = new JButton("Enter Player 2");
        player2Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player2Button.setMaximumSize(new Dimension(140,50));
        player2Button.addActionListener(this);
        player2Button.setVisible(false);
      

        player3Button = new JButton("Enter Player 3");
        player3Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player3Button.setMaximumSize(new Dimension(140,50));
        player3Button.addActionListener(this);
        player3Button.setVisible(false);
        

        player4Button = new JButton("Enter Player 4");
        player4Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player4Button.setMaximumSize(new Dimension(140,50));
        player4Button.addActionListener(this);
        player4Button.setVisible(false);

        
        centerPanel2.add(player1Button);
        centerPanel2.add(player2Button);
        centerPanel2.add(player3Button);
        centerPanel2.add(player4Button);
        
        centerPanel2.setPreferredSize(new Dimension(140,200));
        

        
        // center panel
        addPlayerButton = new JButton("Add Player");
        addPlayerButton.setPreferredSize(new Dimension(120,50));
        addPlayerButton.setFont(new Font("Arial", Font.PLAIN, 15));
        addPlayerButton.addActionListener(this);

        centerPanel = new JPanel();
        centerPanel.setLayout(new FlowLayout() );
        centerPanel.add(centerPanel3);
        centerPanel.add(centerPanel1);
        centerPanel.add(centerPanel2);
        centerPanel.add(addPlayerButton);

        // Borders for inner panels
        //centerPanel1.setBorder(BorderFactory.createLineBorder(Color.black));
        //centerPanel3.setBorder(BorderFactory.createLineBorder(Color.black));
        //centerPanel2.setBorder(BorderFactory.createLineBorder(Color.black));

        // mainPanel
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);


        setContentPane(mainPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setResizable(false);
        setVisible(true);
        

    }

    public void actionPerformed(ActionEvent evt) {
        if(evt.getSource() == player1Button) {

            String name = player_name1.getText();
            player1_Hum = new HumanPlayer(name);
            player_array[0] = player1_Hum;
        }

        else if (evt.getSource() == player2Button){
            String name = player_name2.getText();
            player2_Hum = new HumanPlayer(name);
            player_array[1] = player2_Hum;
        }

        else if (evt.getSource() == player3Button){
            String name = player_name3.getText();
            player3_Hum = new HumanPlayer(name);
            player_array[2] = player3_Hum;
        }

        else if (evt.getSource() == player4Button){
            String name = player_name4.getText();
            player4_Hum = new HumanPlayer(name);
            player_array[3] = player4_Hum;
        }


        else if (evt.getSource() == go_back_button ){
            dispose();
            MainMenu menu = new MainMenu();
        }

        else if (evt.getSource() == createGame_button || evt.getSource() == createGame_button2 ){
            dispose();
            GameWindow gameWindow = new GameWindow(player_array);
        }

        else if (evt.getSource() == addPlayerButton){

            if( player_counter < 4 ){
                player_counter++;

                if(player_counter == 2)
                {
                    player2Button.setVisible(true);
                    player_name2.setVisible(true);
                    player2Label.setVisible(true);
                    removePlayer_button.setVisible(true);
                } 

                else if (player_counter == 3)
                {player3Button.setVisible(true);player_name3.setVisible(true);player3Label.setVisible(true);}

                else if (player_counter == 4)
                {player4Button.setVisible(true);
                 player_name4.setVisible(true);
                 player4Label.setVisible(true);
                 addPlayerButton.setVisible(false);
                 createGame_button2.setVisible(true);
                }
            }
        }

        else if (evt.getSource() == removePlayer_button){

            System.out.println("clicked");
            if (player_counter == 4)
            {
                player4Button.setVisible(false);
                player_name4.setVisible(false);
                player4Label.setVisible(false);
                
                addPlayerButton.setVisible(true);

                player_array[3] = player4_AI;
            }

            else if (player_counter == 3)
            {
                player3Button.setVisible(false);
                player_name3.setVisible(false);
                player3Label.setVisible(false);

                player_array[2] = player3_AI;

            }

            
            else if (player_counter == 2)
            {
                player2Button.setVisible(false);
                player_name2.setVisible(false);
                player2Label.setVisible(false);

                player_array[1] = player2_AI;

                removePlayer_button.setVisible(false);

            }

            player_counter--;
        }
    }   
}