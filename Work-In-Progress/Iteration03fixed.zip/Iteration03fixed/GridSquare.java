import java.awt.*;
import javax.swing.*;

/*
 *  A GUI component
 *
 *  A simple extension of JPanel which records its
 *  coordinates in xcoord and ycoord, NOT in 'x' and 'y'.
 *  Why not? Because 'x' and 'y' are already attributes of
 *  the panel (super) class which say where to draw it in the window.
 *
 *  The game grid and allows the background colour to be set with ease.
 *
 *  @author mhatcher
 */
public class GridSquare extends JPanel
{
    private int xcoord, ycoord;  
    // location in the grid
    private boolean runnerStatus;
    private JPanel p1_Panel, p2_Panel, p3_Panel, p4_Panel;
    // constructor takes the x and y coordinates of this square
    public GridSquare(int xcoord, int ycoord)
    {
        super();
        this.setSize(100,100);
        this.xcoord = xcoord;
        this.ycoord = ycoord;
        
        this.runnerStatus=false;
    }
    

    public void allowMarkers(){
        this.setLayout(new GridLayout(2,2));
        p1_Panel = new JPanel();
        p1_Panel.setVisible(false);
        p2_Panel = new JPanel();
        p2_Panel.setVisible(false);
        p3_Panel = new JPanel();
        p3_Panel.setVisible(false);
        p4_Panel = new JPanel();
        p4_Panel.setVisible(false);
        this.add(p1_Panel); this.add(p2_Panel); this.add(p3_Panel); this.add(p4_Panel);
        
    }




    public void saveRunner(int p){

        if ( p == 1 ){ 
            this.p1_Panel.setBackground(Color.CYAN);
            this.p1_Panel.setVisible(true);
            }
        else if ( p == 2 ){ 
            this.p2_Panel.setBackground(Color.MAGENTA);
            this.p2_Panel.setVisible(true);
            }
        else if ( p == 3 ){ 
            this.p3_Panel.setBackground(Color.ORANGE);
            this.p3_Panel.setVisible(true);
            }
        else if ( p == 4 ){ 
            this.p4_Panel.setBackground(Color.GREEN);
            this.p4_Panel.setVisible(true);
            }
        //this.setBackground(Color.GREEN);
        this.runnerStatus=false;
    }




    // if the decider is even, it chooses black, otherwise white (for 'column+row' will allow a chequerboard effect)
    public void setColor( int decider)
    {
        if(decider==2){
            this.setBackground(Color.RED);
            setOpaque(true);
        
        }
        else if( decider == 1){
            //this.setBackground(Color.gray);
            setOpaque(false);
        }
    }
    
    public void set_Header(int num){
        JLabel head = new JLabel(""+num);
        head.setFont(new Font("Ariel", Font.BOLD, 30));
        head.setForeground(Color.WHITE);
        this.add(head);
    }
    
    public boolean containsRunner(){
        return this.runnerStatus;
    }
    
    public void setRunner(){
        this.setBackground(Color.WHITE);
        this.runnerStatus=true;
    }
    
    public void removeRunner(){
        this.setBackground(Color.RED);
        this.runnerStatus=false;
    }
    // if the square is black it becomes white, and vice-versa
    public void switchColor()
    {
        this.setBackground(Color.RED);
    }
    
    public void saveRunner(){
        this.setBackground(Color.GREEN);
        this.runnerStatus=false;
    }
    // simple setters and getters
    public void setXcoord(int value)    { xcoord = value; }
    public void setYcoord(int value)    { ycoord = value; }
    public int getXcoord()              { return xcoord; }
    public int getYcoord()              { return ycoord; }
}
