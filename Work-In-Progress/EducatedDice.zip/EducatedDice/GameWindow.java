import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;
import java.sql.Time;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.Timer;
import java.util.List;
import java.util.Random;


public class GameWindow extends JFrame implements ActionListener, MouseListener {
    private final String BG_IMAGE_PATH = "ingamebg.jpg";
    private Image bgImage;
    private final ImgPanel bgPanel;
    private final JPanel topPanel;
    private final JPanel bottomPanel0;
    private final JPanel bottomPanel1;
    private final JPanel bottomPanel2;
    private final JPanel rightPanel;
    private final JPanel glassPane;               // Panels
    private JLabel instructionLabel;
    private final JLabel turn_label;
    //    private final JLabel dice_label1;
//    private final JLabel dice_label2;
//    private final JLabel dice_label3;
//    private final JLabel dice_label4;        // UI labels
    private final Combination dice_comb1;
    private final Combination dice_comb2;
    private final Combination dice_comb3;
    private final Combination dice_comb4;
    private final Combination dice_comb5;
    private final Combination dice_comb6; // Combination buttons
    private final JRadioButton rb1;
    private final JRadioButton rb2;
    private final JButton topButton;
    //    private final JButton roll_Button;
    private final JButton endTurn_button;
    private final GridSquare[][] gridSquares;
    private final Game current_game;
    private final Player player1;
    private final Player player2;
    private final Player player3;
    private final Player player4;
    private Player currPlayer;
    private Player nextPlayer;
    private final ArrayList<Player> playersList;
    private final ArrayList<Combination> combinationList;
    private final HashMap<Integer, Integer> runnerPosition;
    private final ArrayList<Integer> runnerCoordinates;
    private final Player[] players;
    private final int rows;
    private final int columns;
    private int counter;
    private int runnerCounter;


    // ---------------------------------------------------------------

    private final DicePanel dicePanel;

    // ---------------------------------------------------------------

    public GameWindow(Player[] players) {
        dicePanel = new DicePanel(3000);
        dicePanel.setCallback(this::handleRoll);
        this.rows = 15;
        this.columns = 15;
        this.setSize(1000, 900);

        this.players = players;
        player1 = players[0];
        player2 = players[1];
        player3 = players[2];
        player4 = players[3];

        playersList = new ArrayList<>();
        playersList.add(player1);
        playersList.add(player2);
        playersList.add(player3);
        playersList.add(player4);

        currPlayer = playersList.get(0);

        this.runnerCounter = 0;
        runnerCoordinates = new ArrayList<>();
        runnerPosition = new HashMap<>();
        combinationList = new ArrayList<>();

        current_game = new Game(playersList);
        loadAssets();
        bgPanel = new ImgPanel(bgImage);

        topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        topPanel.setBorder(BorderFactory.createLineBorder(Color.black));    //

        bottomPanel0 = new JPanel();
        bottomPanel0.setLayout(new BorderLayout());
        bottomPanel0.setBorder(BorderFactory.createLineBorder(Color.black));

        bottomPanel1 = new JPanel();
        bottomPanel1.setBorder(BorderFactory.createLineBorder(Color.black));
        bottomPanel1.setPreferredSize(new Dimension(300, 50));

        bottomPanel2 = new JPanel();
        bottomPanel2.setLayout(new GridLayout(rows, columns));
        bottomPanel2.setSize(200, 200);
        bottomPanel2.setBorder(BorderFactory.createLineBorder(Color.black));

        rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.PAGE_AXIS));
        rightPanel.setPreferredSize(new Dimension(300, 200));
        rightPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        rightPanel.add(dicePanel);

        topButton = new JButton("Options");
        topButton.addActionListener(this);
        topPanel.add(topButton);

        gridSquares = new GridSquare[rows][columns];
        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < columns; y++) {
                gridSquares[x][y] = new GridSquare(x, y);
                gridSquares[x][y].setColor(1);
                bottomPanel2.add(gridSquares[x][y]);
                gridSquares[x][y].setBorder(BorderFactory.createLineBorder(Color.black));
            }
        }


        // create board
        for (int x = 0; x < 14; x++) {
            if (x < 5) {
                for (int z = 6 - x; z <= 6 + x; z++) {
                    gridSquares[x + 1][z + 1].setColor(2);
                    gridSquares[x + 1][z + 1].setSize(300, 300);
                    gridSquares[x + 1][z + 1].setBorder(BorderFactory.createLineBorder(Color.black));
                }
            }

            if (x >= 5 && x <= 7) {
                for (int z = 6 - 5; z <= 6 + 5; z++) {
                    gridSquares[x + 1][z + 1].setColor(2);
                    gridSquares[x + 1][z + 1].setSize(300, 300);
                    gridSquares[x + 1][z + 1].setBorder(BorderFactory.createLineBorder(Color.black));
                }
            }
            if (x >= 8 && x <= 12) {
                for (int z = x - 6; z <= 18 - x; z++) {
                    gridSquares[x + 1][z + 1].setColor(2);
                    gridSquares[x + 1][z + 1].setSize(300, 300);
                    gridSquares[x + 1][z + 1].setBorder(BorderFactory.createLineBorder(Color.black));
                }
            }
        }

        // column Numbers
        int r = 5;
        for (int c = 2; c <= 12; c++) {
            gridSquares[Math.abs(r)][c].set_Header(c);
            r--;
        }

        // add panels to bottomPanel0
        bottomPanel0.add(bottomPanel1, BorderLayout.NORTH);
        bottomPanel0.add(bottomPanel2, BorderLayout.CENTER);

        // Right panel contents
//        roll_Button = new JButton("Roll");
//        roll_Button.setAlignmentX(CENTER_ALIGNMENT);
//        roll_Button.setPreferredSize(new Dimension(50, 50));
//        roll_Button.addActionListener(this);
//        roll_Button.setEnabled(false);
        endTurn_button = new JButton("End Turn");
        endTurn_button.setAlignmentX(CENTER_ALIGNMENT);
        endTurn_button.setPreferredSize(new Dimension(50, 50));
        endTurn_button.addActionListener(this);


//        dice_label1 = new JLabel("N/A");
//        dice_label1.setAlignmentX(CENTER_ALIGNMENT);
//        dice_label1.setFont(new Font("Ariel", Font.PLAIN, 30));
//        dice_label2 = new JLabel("N/A");
//        dice_label2.setAlignmentX(CENTER_ALIGNMENT);
//        dice_label2.setFont(new Font("Ariel", Font.PLAIN, 30));
//        dice_label3 = new JLabel("N/A");
//        dice_label3.setAlignmentX(CENTER_ALIGNMENT);
//        dice_label3.setFont(new Font("Ariel", Font.PLAIN, 30));
//        dice_label4 = new JLabel("N/A");
//        dice_label4.setAlignmentX(CENTER_ALIGNMENT);
//        dice_label4.setFont(new Font("Ariel", Font.PLAIN, 30));

        dice_comb1 = new Combination(0);
        dice_comb1.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb1.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb1.setColor(2);
        dice_comb1.setVisible(false);
        dice_comb1.addMouseListener(this);

        dice_comb2 = new Combination(0);
        dice_comb2.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb2.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb2.setVisible(false);
        dice_comb2.addMouseListener(this);

        dice_comb3 = new Combination(0);
        dice_comb3.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb3.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb3.setVisible(false);
        dice_comb3.addMouseListener(this);

        dice_comb4 = new Combination(0);
        dice_comb4.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb4.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb4.setVisible(false);
        dice_comb4.addMouseListener(this);

        dice_comb5 = new Combination(0);
        dice_comb5.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb5.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb5.setVisible(false);
        dice_comb5.addMouseListener(this);

        dice_comb6 = new Combination(0);
        dice_comb6.setAlignmentX(CENTER_ALIGNMENT);
        dice_comb6.setFont(new Font("Ariel", Font.PLAIN, 30));
        dice_comb6.setVisible(false);
        dice_comb6.addMouseListener(this);

        turn_label = new JLabel(playersList.get(0).getName());
        turn_label.setAlignmentX(CENTER_ALIGNMENT);
        turn_label.setFont(new Font("Ariel", Font.PLAIN, 30));

        rightPanel.add(turn_label);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 50)));
        rightPanel.add(Box.createVerticalGlue());
//        rightPanel.add(dice_label1);
//        rightPanel.add(dice_label2);
//        rightPanel.add(dice_label3);
//        rightPanel.add(dice_label4);
        JPanel combinationsPanel = new JPanel();
        combinationsPanel.setLayout(new GridLayout(3, 2));
        combinationsPanel.add(dice_comb1);
        combinationsPanel.add(dice_comb2);
        combinationsPanel.add(dice_comb3);
        combinationsPanel.add(dice_comb4);
        combinationsPanel.add(dice_comb5);
        combinationsPanel.add(dice_comb6);
        rightPanel.add(combinationsPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 150)));
        rightPanel.add(endTurn_button);
//        rightPanel.add(roll_Button);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 150)));


        //topPanel.setOpaque(false);
        bottomPanel0.setOpaque(false);
        bottomPanel1.setOpaque(false);
        bottomPanel2.setOpaque(false);
        //rightPanel.setOpaque(false);


        // now add the top and bottom panels to the main frame
        bgPanel.setLayout(new BorderLayout());
        bgPanel.add(topPanel, BorderLayout.NORTH);
        bgPanel.add(bottomPanel0, BorderLayout.CENTER);
        bgPanel.add(new JScrollPane(rightPanel), BorderLayout.EAST);
        setContentPane(bgPanel);


        //access glass pane for OptionsMenu
        glassPane = (JPanel) this.getGlassPane();
        //glassPane.setBackground( new Color(255, 0, 0, 20) );
        glassPane.addMouseListener(new MouseAdapter() {
        });
        glassPane.setLayout(new GridBagLayout());

        JPanel glassJPanel = new JPanel();
        glassJPanel.setLayout(new BoxLayout(glassJPanel, BoxLayout.PAGE_AXIS));
        glassJPanel.setPreferredSize(new Dimension(300, 420));
        glassJPanel.setBackground(Color.red);
        glassJPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        glassJPanel.setAlignmentX(CENTER_ALIGNMENT);
        glassJPanel.setAlignmentY(CENTER_ALIGNMENT);

        // buttons to save or exit game
        JButton returnToGameButton = new JButton("Return to game");
        returnToGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                glassPane.setVisible(false);
            }
        }); //

        JButton exitGameButton = new JButton("Return to Main Menu");
        exitGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                MainMenu menu = new MainMenu();
            }
        }); //

        JButton saveGameButton = new JButton("Save game");
        saveGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //call method to save
                current_game.saveGame();
            }
        }); //

        JButton[] buttons = {returnToGameButton, saveGameButton, exitGameButton};
        arrangeButtons(buttons);

        rb1 = new JRadioButton("Size 1");
        rb1.setAlignmentX(CENTER_ALIGNMENT);

        rb2 = new JRadioButton("Size 2");
        rb2.setAlignmentX(CENTER_ALIGNMENT);
        ButtonGroup b_Group = new ButtonGroup();
        b_Group.add(rb1);
        b_Group.add(rb2);
        rb1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                System.out.println("rb1");
                getContentPane().setPreferredSize(new Dimension(1000, 1000));

            }

        }); //
        rb2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                System.out.println("rb2");
                getContentPane().setPreferredSize(new Dimension(2000, 2000));
                // setVisible(true);

            }
        });

        // add components to glassPanel
        glassJPanel.add(Box.createVerticalGlue());
        glassJPanel.add(Box.createRigidArea(new Dimension(0, 25)));
        glassJPanel.add(returnToGameButton);
        glassJPanel.add(Box.createRigidArea(new Dimension(0, 50)));
        glassJPanel.add(exitGameButton);
        glassJPanel.add(Box.createRigidArea(new Dimension(0, 50)));
        glassJPanel.add(saveGameButton);
        glassJPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        glassJPanel.add(rb1);
        glassJPanel.add(rb2);

        glassPane.add(glassJPanel);

        // housekeeping : behaviour
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setVisible(true);

    }

    public void loadAssets() {
        try {
            bgImage = ImageIO.read(new File(BG_IMAGE_PATH));
        } catch (Exception e) {
            System.out.println("failed to load in-game background image; " + e.getMessage());
        }
    }

    public List<Integer> giveFail() {
//        Dice failDice = new Dice();
        List<Integer> rollValues = dicePanel.getRollValues();
        while (!currPlayer.getFailCombination()) {
            List<List<Integer>> combinations = CombinationUtil.createPairCombinations(rollValues);
            if (combinations.stream().anyMatch(combination ->
                    currPlayer.getRunnerCoordinates()
                            .contains(combination.get(0) + combination.get(1)))) {
                rollValues = dicePanel.rollInstantly();
            } else {
                currPlayer.setFailCombination(true);
            }
        }
        return rollValues;
    }

    public void changeCombinationLabels(Dice dice) {
        //get face values from Dice
        int w = dice.get_val1();
        int x = dice.get_val2();
        int y = dice.get_val3();
        int z = dice.get_val4();

        //Display values
//        dice_label1.setText("" + w);
//        dice_label2.setText("" + x);
//        dice_label3.setText("" + y);
//        dice_label4.setText("" + z);

        dice_comb1.setText("" + w + " " + x);
        dice_comb1.setValue(dice.get_comb1());
        dice_comb1.setVisible(true);

        dice_comb2.setText("" + x + " " + y);
        dice_comb2.setValue(dice.get_comb2());
        dice_comb2.setVisible(true);

        dice_comb3.setText("" + y + " " + z);
        dice_comb3.setValue(dice.get_comb3());
        dice_comb3.setVisible(true);

        dice_comb4.setText("" + w + " " + y);
        dice_comb4.setValue(dice.get_comb4());
        dice_comb4.setVisible(true);

        dice_comb5.setText("" + x + " " + z);
        dice_comb5.setValue(dice.get_comb5());
        dice_comb5.setVisible(true);

        dice_comb6.setText("" + w + " " + z);
        dice_comb6.setValue(dice.get_comb6());
        dice_comb6.setVisible(true);
    }

    public void changeCombinationLabels(List<Integer> rollValues) {
        //get face values from Dice
        int w = rollValues.get(0);
        int x = rollValues.get(1);
        int y = rollValues.get(2);
        int z = rollValues.get(3);


        //Display values
//        dice_label1.setText("" + w);
//        dice_label2.setText("" + x);
//        dice_label3.setText("" + y);
//        dice_label4.setText("" + z);

        dice_comb1.setText("" + w + " " + x);
        dice_comb1.setValue(w + x);
        dice_comb1.setVisible(true);

        dice_comb2.setText("" + x + " " + y);
        dice_comb2.setValue(x + y);
        dice_comb2.setVisible(true);

        dice_comb3.setText("" + y + " " + z);
        dice_comb3.setValue(y + z);
        dice_comb3.setVisible(true);

        dice_comb4.setText("" + w + " " + y);
        dice_comb4.setValue(w + y);
        dice_comb4.setVisible(true);

        dice_comb5.setText("" + x + " " + z);
        dice_comb5.setValue(x + z);
        dice_comb5.setVisible(true);

        dice_comb6.setText("" + w + " " + z);
        dice_comb6.setValue(w + z);
        dice_comb6.setVisible(true);
    }


//    public void simulateDiceRoll() {
//        combinationList.clear();
//        currPlayer.setSelectionCounter(0);
//        Dice dice = new Dice();
//        currPlayer.setFailCombination(false);
//
//        if (currPlayer.getRolledDice() > 4 && runnerCounter == 3) {
//            dice = giveFail();
//        }
//
//        changeCombinationLabels(dice);
//
//        if (currPlayer.getFailCombination()) {
//            turn_label.setText(currPlayer.getName() + "failed");
//            startNewPlayerTurn();
//        } else if (currPlayer instanceof IntelligentPlayer) {
//            combinationList.add(dice_comb1);
//            combinationList.add(dice_comb2);
//            combinationList.add(dice_comb3);
//            combinationList.add(dice_comb4);
//            combinationList.add(dice_comb5);
//            combinationList.add(dice_comb6);
//            autoSelection();
//        }
//    }

    public void placeRunners(int column) {
        boolean runnerFound = false;
        if (1 < column && column < 8) {
            for (int r = 8 - column; r <= column + 6; r++) {
                if (gridSquares[r][column].containsRunner()) {
                    gridSquares[r][column].removeRunner();
                    gridSquares[r - 1][column].setRunner();
                    runnerPosition.put(column, r - 1);
                    runnerFound = true;
                }
            }
            if (runnerFound == false && runnerCounter < 3) {
                gridSquares[column + 6][column].setRunner();
                runnerCoordinates.add(column);
                runnerPosition.put(column, column + 6);
                runnerCounter++;

            }
        } else if (7 < column && column < 13) {
            for (int r = column - 6; r <= (20 - column); r++) {
                if (gridSquares[r][column].containsRunner()) {
                    gridSquares[r - 1][column].setRunner();
                    runnerPosition.put(column, r - 1);
                    gridSquares[r][column].removeRunner();
                    runnerFound = true;
                }
            }
            if (runnerFound == false && runnerCounter < 3) {
                gridSquares[20 - column][column].setRunner();
                runnerCoordinates.add(column);
                runnerPosition.put(column, 20 - column);
                runnerCounter++;
            }
        }
    }

    public void selectionWork(int value) {

        int delay = 3000;
        Timer ourTime = new Timer(delay, e-> {
            if (currPlayer.getSelectionCounter()<2){
            currPlayer.setSelectionCounter(currPlayer.getSelectionCounter()+1);
            Combination currCombination = combinationList.get(value);
            int column = currCombination.getValue(); 
            int d = 2000;
            Timer miniDelay = new Timer(d, f->{
                currCombination.setBackground(Color.BLUE);
            });
            miniDelay.start();
            miniDelay.setRepeats(false);
            
            //currCombination.setBackground(Color.BLUE);
            placeRunners(column);
        }
                    
        });
        ourTime.start();
        ourTime.setRepeats(false);

    }

    public void autoSelection() {
        Random rand = new Random();
        int val1 = rand.nextInt(6);
        int val2 = rand.nextInt(6);
        while (val1 == val2) {
            val1 = rand.nextInt(6);
            val2 = rand.nextInt(6);
        }
        selectionWork(val1);
        selectionWork(val2);
        currPlayer.setRolledDice(currPlayer.getRolledDice()+1);
        int delay = 3000;
        Timer ourTime = new Timer(delay, e-> {
            simulateDiceRoll(); 
        });
        ourTime.start();
        ourTime.setRepeats(false);
    }

    private void simulateDiceRoll() {
        dicePanel.setCallback(this::handleRoll);
        dicePanel.roll();
    }


    public void startNewPlayerTurn() {

        
            currPlayer.setRolledDice(0);
            currPlayer.setSelectionCounter(0);
            this.runnerCounter = 0;
            for (int r = 0; r < 15; r++) {
                for (int c = 0; c < 15; c++) {
                    if (gridSquares[r][c].containsRunner())
                        gridSquares[r][c].removeRunner();
                }
            }
            if (currPlayer.equals(playersList.get(3))) {
                currPlayer = playersList.get(0);
            } else {
                if (currPlayer.equals(playersList.get(0))) {
                    currPlayer = playersList.get(1);
                } else if (currPlayer.equals(playersList.get(1))) {
                    currPlayer = playersList.get(2);
                } else if (currPlayer.equals(playersList.get(2))) {
                    currPlayer = playersList.get(3);
                }
            }
         turn_label.setText(currPlayer.getName());
        int delay = 3000;
        Timer ourTime = new Timer(delay, e-> {
            currPlayer.setRolledDice(currPlayer.getRolledDice()+1);
            simulateDiceRoll();
        });
        ourTime.start();
        ourTime.setRepeats(false);
    }


    //
    public void arrangeButtons(JButton[] buttons) {
        for (JButton button : buttons) {
            button.setAlignmentX(CENTER_ALIGNMENT);
        }
    }


    /*
     *  handles actions performed in the gui
     *  this method must be present to correctly implement the ActionListener interface
     */
    public void actionPerformed(ActionEvent aevt) {
        // get the object that was selected in the gui
        Object selected = aevt.getSource();

        // if resetting the squares' colours is requested then do so
        if (selected.equals(topButton)) {
            glassPane.setVisible(true);
        }
//        else if (selected.equals(roll_Button)) {
//            currPlayer.setRolledDice(currPlayer.getRolledDice() + 1);
////            simulateDiceRoll();
//        }
    }


    public void handleRoll(List<Integer> rollValues) {
        currPlayer.setRolledDice(currPlayer.getRolledDice() + 1);

        combinationList.clear();
        currPlayer.setSelectionCounter(0);

        Dice dice = new Dice();
        currPlayer.setFailCombination(false);

        if (currPlayer.getRolledDice() > 4 && runnerCounter == 3) {
            rollValues = giveFail();
        }

        changeCombinationLabels(rollValues);

        if (currPlayer.getFailCombination()) {
                turn_label.setText(currPlayer.getName()+ "failed"); 
                int delay = 3000;
                Timer ourTime = new Timer(delay, e-> {
                    startNewPlayerTurn();
                    
                });
                ourTime.start();
                ourTime.setRepeats(false);
        } else if (currPlayer instanceof IntelligentPlayer) {
            combinationList.add(dice_comb1);
            combinationList.add(dice_comb2);
            combinationList.add(dice_comb3);
            combinationList.add(dice_comb4);
            combinationList.add(dice_comb5);
            combinationList.add(dice_comb6);
            autoSelection();
        }
    }

    // Mouse Listener events
    public void mouseClicked(MouseEvent mevt) {
        Object selected = mevt.getSource();

        if (selected instanceof Combination && currPlayer.getSelectionCounter() < 2) {
            currPlayer.setSelectionCounter(currPlayer.getSelectionCounter() + 1);
            Combination currCombination = (Combination) selected;
            int column = currCombination.getValue();
            currCombination.setText("You selected" + column);
            placeRunners(column);
        } else if (selected instanceof Combination && currPlayer.getSelectionCounter() == 2) {
            Combination invalid = (Combination) selected;
            invalid.setText("INVALID");
        }
    }


    // not used but must be present to fulfil MouseListener contract
    public void mouseEntered(MouseEvent arg0) {
    }

    public void mouseExited(MouseEvent arg0) {
    }

    public void mousePressed(MouseEvent arg0) {
    }

    public void mouseReleased(MouseEvent arg0) {
    }
}