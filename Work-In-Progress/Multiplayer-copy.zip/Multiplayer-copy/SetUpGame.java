

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class SetUpGame extends JFrame implements ActionListener{

    private JButton go_back_button, player1Button, player2Button, player3Button, player4Button,  createGame_button;
    private JPanel mainPanel, topPanel, centerPanel, centerPanel1, centerPanel2,  bottomPanel;
    private JTextField player_name1, player_name2, player_name3, player_name4;
    //private int player_counter = 1;

    private String[] playerName_array = {null,null,null,null};
    
    //
    public SetUpGame()
    {
        // top panel
        topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.LINE_AXIS));

        go_back_button = new JButton("Back");
        go_back_button.setFont(new Font("Arial", Font.PLAIN, 15));
        go_back_button.setPreferredSize(new Dimension(70,30));
        go_back_button.addActionListener(this);

        topPanel.add(go_back_button);
        topPanel.add(Box.createHorizontalGlue());        

        // bottom panel - contains create game button
        bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.LINE_AXIS));

        createGame_button = new JButton("Create game");
        createGame_button.setFont(new Font("Arial", Font.PLAIN, 15));
        createGame_button.setPreferredSize(new Dimension(150,30));
        createGame_button.addActionListener(this);

        bottomPanel.add(Box.createHorizontalGlue());
        bottomPanel.add(createGame_button);


        // center panel - contains addPlayer button
        centerPanel1 = new JPanel();
        //centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        //centerPanel.setLayout(new BorderLayout());
        centerPanel1.setLayout(new BoxLayout(centerPanel1, BoxLayout.PAGE_AXIS));
        

        player_name1 = new JTextField("Default name ");
        player_name1.setMaximumSize(new Dimension(100,50));
        player_name1.setPreferredSize(new Dimension(new Dimension(200,40)));
       

        player_name2 = new JTextField("Default name 2");
        player_name2.setMaximumSize(new Dimension(100,50));
        player_name2.setPreferredSize(new Dimension(new Dimension(200,40)));
       

        player_name3 = new JTextField("Defualt name 3");
        player_name3.setMaximumSize(new Dimension(100,50));
        player_name3.setPreferredSize(new Dimension(new Dimension(200,40)));
        

        player_name4 = new JTextField("Default name 4");
        player_name4.setMaximumSize(new Dimension(100,50));
        player_name4.setPreferredSize(new Dimension(new Dimension(200,40)));
        
        centerPanel1.setPreferredSize(new Dimension(150,200));
        
        centerPanel1.add(player_name1); 
        centerPanel1.add(player_name2);
        centerPanel1.add(player_name3);
        centerPanel1.add(player_name4);   
            
        centerPanel1.setBorder(BorderFactory.createLineBorder(Color.black));
        //
        centerPanel2 = new JPanel();
        centerPanel2.setLayout(new BoxLayout(centerPanel2, BoxLayout.PAGE_AXIS));

        player1Button = new JButton("Player 1");
        player1Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player1Button.setPreferredSize(new Dimension(100,50));
        player1Button.addActionListener(this);
       
        //addPlayer_button.addActionListener(this);

        player2Button = new JButton("Player 2");
        player2Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player2Button.setPreferredSize(new Dimension(100,50));
        player2Button.addActionListener(this);
      

        player3Button = new JButton("Player 3");
        player3Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player3Button.setPreferredSize(new Dimension(100,50));
        player3Button.addActionListener(this);
        

        player4Button = new JButton("Player 4");
        player4Button.setFont(new Font("Arial", Font.PLAIN, 15));
        player4Button.setPreferredSize(new Dimension(100,50));
        player4Button.addActionListener(this);

        
        centerPanel2.add(player1Button);
        centerPanel2.add(player2Button);
        centerPanel2.add(player3Button);
        centerPanel2.add(player4Button);
        
        centerPanel2.setPreferredSize(new Dimension(200,200));
        centerPanel2.setBorder(BorderFactory.createLineBorder(Color.black));

        
        // center panel

        centerPanel = new JPanel();
        centerPanel.setLayout(new FlowLayout() );
        centerPanel.add(centerPanel1);
        centerPanel.add(centerPanel2);


        // mainPanel
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);


        setContentPane(mainPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setResizable(false);
        setVisible(true);
        

    }

    public void actionPerformed(ActionEvent evt) {
        if(evt.getSource() == player1Button) {

            String name = player_name1.getText();
            playerName_array[0] = name;
           
        }

        else if (evt.getSource() == player2Button){
            String name = player_name2.getText();
            playerName_array[1] = name;
           
        }

        else if (evt.getSource() == player3Button){
            String name = player_name3.getText();
            playerName_array[2] = name;
           
        }

        else if (evt.getSource() == player4Button){
            String name = player_name4.getText();
            playerName_array[3] = name;
            
        }


        else if (evt.getSource() == go_back_button ){
            dispose();
            MainMenu menu = new MainMenu();
        }

        else if (evt.getSource() == createGame_button){
            dispose();
            GameWindow gameWindow = new GameWindow(playerName_array);
        }
    }

    
}
